const express = require('express');
const router = express.Router();

router.get('/movies', function (req, res) {
    const arr2 = ["rand de basnasti" , "the shining", "lord of the rings", "bartman begins"]
 
 
    res.send(arr2)
    
 });
 
 
 router.get('/movies/:indexnumber', function (req, res) {
      const value = req.params.indexnumber
 
    const arr = ["rand de basnasti" , "the shining", "lord of the rings", "bartman begins"]
    const arrlen = arr.length
    if (value < arrlen) {
       res.send(arr[value])
    } else {
       let str = "use a valid index"
       res.send(str)
    }
 
 });